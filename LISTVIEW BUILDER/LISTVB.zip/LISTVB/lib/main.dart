import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import the intl package for date formatting
import 'event.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final List<Event> events = [
    Event(
      title: 'Hey',
      description: 'jbhb buhifehfivev ihugiejfoiwf iheihfiebfifevu',
      date: DateTime(2023, 7, 20),
    ),
    Event(
      title: 'Hey',
      description: 'Content',
      date: DateTime(2023, 7, 21),
    ),

  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(


           leading: IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {

              },
            ),
          title: Text('Events List'),
        ),
        body: ListView.builder(
          itemCount: events.length,
          itemBuilder: (context, index) {
            return EventBox(event: events[index]);
          },
        ),
      ),
    );
  }
}

class EventBox extends StatelessWidget {
  final Event event;

  EventBox({required this.event});

  @override
  Widget build(BuildContext context) {
    final formattedDate = DateFormat('yyyy-MM-dd').format(event.date);

    return Container(
      margin: EdgeInsets.all(8.0),
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.grey,
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            event.title,
            style: TextStyle(
              color: Colors.indigo,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(event.description, style: TextStyle(
            color: Colors.indigo,),),
          SizedBox(height: 8),
          Align(
            alignment: Alignment.bottomRight, // Align the date to the right bottom
            child: Text('Date: $formattedDate'),
          ),
        ],
      ),
    );
  }
}
